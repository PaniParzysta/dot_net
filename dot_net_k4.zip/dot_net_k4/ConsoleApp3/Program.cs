﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;


namespace ConsoleApp4
{
    class ludzio{
        public int ID { set; get; }
        public string imie { set; get; }
        public string nazwisko { set; get; }
    }
    class ludziki : DbContext{
        public virtual DbSet<ludzio> czlek { set; get; }
    }
    class program{
        static void Main(string[] args){

            var baza = new ludziki();
            ludzio ludz_1 = new ludzio { imie = "Arkadiusz ", nazwisko = "Alienowski \n" };
            ludzio ludz_2 = new ludzio { imie = "Amadeusz ", nazwisko = "Kosmicki \n" };
            ludzio ludz_3 = new ludzio { imie = "Antropiusz ", nazwisko = "Kosmopolitańczykowianeczek \n" };

            baza.czlek.Add(ludz_1);
            baza.czlek.Add(ludz_2);
            baza.czlek.Add(ludz_3);
            baza.SaveChanges();

            var wyp_ludzia = (from v in baza.czlek select v).ToList<ludzio>();
            
            foreach (var klasa in wyp_ludzia){

                Console.Write(" iD " + klasa.ID);
                Console.Write(klasa.imie);
                Console.Write(klasa.nazwisko);
            }
            Console.Read();
        }
    }
}